'use client';

import React from 'react';
import { Sun, Moon, Search } from 'lucide-react';
import { useTheme } from 'next-themes';
import { useUser, SignInButton, UserButton } from "@clerk/nextjs";

const Header = () => {
  const { theme, setTheme } = useTheme();
  const { isSignedIn, isLoaded } = useUser();

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <Search className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-foreground">SEO Toolbox</h1>
            <p className="text-xs text-muted-foreground">All-in-One SEO Suite</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="inline-flex h-10 w-10 items-center justify-center rounded-md border bg-background text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            aria-label="Toggle theme"
          >
            <Sun className="h-[1.2rem] w-[1.2rem] rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
            <Moon className="absolute h-[1.2rem] w-[1.2rem] rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
          </button>

          {isLoaded && (
            <div className="flex items-center gap-2">
              {!isSignedIn ? (
                <SignInButton mode="modal">
                  <button className="bg-primary text-primary-foreground px-4 py-2 rounded-lg text-sm font-bold hover:opacity-90 transition-opacity">
                    Sign In
                  </button>
                </SignInButton>
              ) : (
                <UserButton 
                  appearance={{
                    elements: {
                      userButtonAvatarBox: "h-10 w-10 rounded-lg"
                    }
                  }}
                />
              )}
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
